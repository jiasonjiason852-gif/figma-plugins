"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * Image HD Plus - Figma 插件
 * API Key 通过代理服务保护，仅配置在 proxy 的 .env 中
 */
const JZ_PROXY_URL = "https://figma-plugins-production.up.railway.app/api/hd";
const MAX_DIMENSION = 2048;
const MAX_SIZE_BYTES = 10 * 1024 * 1024;
function hasImageFill(n) {
    return "fills" in n && Array.isArray(n.fills) && n.fills.some((f) => f.type === "IMAGE");
}
function getImageNodes(selection) {
    return selection.filter((n) => hasImageFill(n));
}
function getSize(n) {
    var _a, _b, _c, _d, _e, _f;
    const x = n;
    return { w: (_c = (_a = x.width) !== null && _a !== void 0 ? _a : (_b = x.bounds) === null || _b === void 0 ? void 0 : _b.width) !== null && _c !== void 0 ? _c : 0, h: (_f = (_d = x.height) !== null && _d !== void 0 ? _d : (_e = x.bounds) === null || _e === void 0 ? void 0 : _e.height) !== null && _f !== void 0 ? _f : 0 };
}
figma.showUI(__html__, { width: 320, height: 240, themeColors: true });
figma.ui.onmessage = (msg) => __awaiter(void 0, void 0, void 0, function* () {
    const notify = (m, err = false) => figma.notify(m, err ? { error: true } : { timeout: 3000 });
    if (msg.type === "hd-trigger") {
        const nodes = getImageNodes(figma.currentPage.selection);
        if (!nodes.length)
            return notify("请先选择包含图像的图层");
        if (nodes.length > 1)
            return notify("请只选择一张图片，单次不支持多图");
        const node = nodes[0];
        const { w, h } = getSize(node);
        if (w > MAX_DIMENSION || h > MAX_DIMENSION)
            return notify(`图片长宽不能超过 2048px（当前 ${Math.round(w)}×${Math.round(h)}）`);
        try {
            notify("正在处理...");
            const bytes = yield node.exportAsync({ format: "PNG" });
            if (bytes.byteLength > MAX_SIZE_BYTES)
                return notify(`图片大小不能超过 10MB（当前 ${(bytes.byteLength / 1024 / 1024).toFixed(1)}MB）`);
            figma.ui.postMessage({ type: "hd-send", imageBytes: bytes.buffer, nodeId: node.id, proxyUrl: JZ_PROXY_URL });
        }
        catch (e) {
            notify("失败：导出图像失败", true);
            figma.ui.postMessage({ type: "hd-error", message: String(e) });
        }
        return;
    }
    if (msg.type === "hd-response") {
        try {
            const node = (yield figma.getNodeByIdAsync(msg.nodeId));
            if (!(node === null || node === void 0 ? void 0 : node.fills) || node.removed || !hasImageFill(node))
                return notify("失败：无法找到原图层", true);
            const buf = msg.imageBytes;
            if (!(buf === null || buf === void 0 ? void 0 : buf.byteLength))
                return notify("失败：未收到图片数据", true);
            const uint8 = buf instanceof ArrayBuffer ? new Uint8Array(buf) : new Uint8Array(buf.buffer);
            const img = figma.createImage(uint8);
            node.fills = node.fills.map((f) => (f.type === "IMAGE" ? Object.assign(Object.assign({}, f), { imageHash: img.hash, scaleMode: "FIT" }) : f));
            notify("高清化完成");
        }
        catch (e) {
            notify("失败：替换图像失败 - " + (e instanceof Error ? e.message : String(e)), true);
        }
        return;
    }
    if (msg.type === "hd-error")
        notify("失败：" + (msg.message || "处理失败"), true);
});
